# Define the XDG base directories explicitly for shells and their children.
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$HOME/.cache}"
export XDG_DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
export XDG_STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"

# Keep Zsh startup files under the XDG configuration directory.
export ZDOTDIR="$XDG_CONFIG_HOME/zsh"

# ~/.local/bin is the XDG-style location for personal scripts; ~/apps is the
# requested location for directly executable personal applications/AppImages.
typeset -U path PATH
path=("$HOME/.local/bin" "$HOME/apps" $path)
export PATH
