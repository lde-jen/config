# Keep Zsh startup files under the XDG configuration directory.
export ZDOTDIR="${XDG_CONFIG_HOME:-$HOME/.config}/zsh"
