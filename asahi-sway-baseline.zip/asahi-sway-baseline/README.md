# Fedora Asahi Sway baseline

This is a deliberately small first configuration for a 2021 14-inch
MacBook Pro (`MacBookPro18,3`, M1 Pro) running Fedora Asahi Remix 44.

It is intended to provide a dependable i3-like daily-driver session before
any elaborate theming is added. KDE Plasma remains installed as a known-good
fallback and hardware-testing environment.

## Final system choice

- Base: Fedora Asahi Remix 44, KDE Plasma edition
- Primary session: Sway 1.11
- Fallback session: KDE Plasma 6.6
- Shell: Zsh, with a small framework-free configuration
- Terminal: Kitty
- File manager: Thunar
- Launcher: Rofi 2.0 on native Wayland
- Bar: Waybar
- Notifications: Mako
- Lock and idle handling: swaylock and swayidle
- Package policy: Fedora/Asahi RPM packages first; no COPR or Flatpak is
  required for this baseline

Sway was selected because it uses the i3 configuration and command model,
is maintained in Fedora 44, and fits Fedora Asahi's Wayland graphics stack.
Hyprland can reproduce the shortcuts, but currently adds a different config
model and a less straightforward Fedora 44 packaging path without providing a
meaningful advantage for this workflow.

## The notch arrangement

The full panel is 3024x1964 physical pixels. At 2x scaling this is 1512x982
logical pixels. Reserving a 37-logical-pixel bar at the top consumes 74
physical pixels, leaving 3024x1890 physical pixels (1512x945 logical pixels):
an exact 16:10 rectangular workspace below the notch.

Waybar is therefore configured to:

- occupy a translucent charcoal, full-width, 37-pixel strip;
- reserve that strip from tiled windows;
- remain above fullscreen content where Sway/Waybar permits;
- leave its centre completely empty;
- show workspaces on the left and system information on the right;
- place each workspace and status component inside a more opaque rounded pill.

The continuous bar backdrop uses 46% opacity, while the component pills use
84% opacity. This allows the wallpaper to remain visible at the top without
making the individual controls difficult to distinguish. The physical notch
will remain completely black and will therefore stand out slightly from the
translucent area on either side.

The height is a mathematically sensible baseline, but should still be checked
against the real panel after installation.

## Safe installation order

### 1. Install and validate the supported baseline

Install the normal Fedora Asahi Remix 44 KDE Plasma edition. On the first KDE
boot, update before adding Sway:

```bash
sudo dnf upgrade --refresh
systemctl reboot
```

In unmodified Plasma, test Wi-Fi, audio, microphone, camera, keyboard,
trackpad, display brightness, battery reporting, lid close and suspend/resume.
Do not enable the notch area yet.

### 2. Install the Sway components

```bash
sudo dnf install \
    sway swaybg swayidle swaylock waybar rofi kitty zsh util-linux-user \
    Thunar mako \
    wl-clipboard grim slurp brightnessctl playerctl pavucontrol \
    network-manager-applet blueman \
    xdg-desktop-portal-wlr xdg-desktop-portal-gtk
```

All of these are ordinary Fedora packages. Firefox, PipeWire, WirePlumber,
NetworkManager and the KDE PolicyKit agent should already be present in the
KDE installation. Do not replace or manually reconfigure Asahi's audio stack.

### 3. Deploy the configuration

Extract this archive, open a terminal in the extracted directory and run:

```bash
chmod +x install.sh
./install.sh
```

The installer copies the configuration beneath `XDG_CONFIG_HOME` (normally
`~/.config`). Existing versions of the six affected component directories and
the small `~/.zshenv` pointer are copied to a timestamped backup first. It also:

- asks `chsh` to make `/usr/bin/zsh` the login shell;
- tells Kitty to launch Zsh explicitly;
- installs a system-level blacklist for the legacy `pcspkr` and `snd_pcsp`
  kernel modules;
- disables Kitty's own audio bell.

The Zsh configuration itself also runs `unsetopt BEEP`, so shell completion and
line-editing errors remain silent even when Zsh is used in another terminal.
Bash is not removed or substituted for `/bin/sh`: scripts with Bash or POSIX
shell shebangs continue to work normally, and `bash` remains available whenever
an application specifically requires it.

Log out, select **Sway** in the login-session menu, and log in. Plasma remains
available from the same menu if Sway does not start correctly.

The complete logout is also required before `$SHELL` reflects the new login
shell. If `chsh` could not complete, run this manually and then log out again:

```bash
chsh -s /usr/bin/zsh
```

### 4. Validate Sway before enabling the notch

Confirm that the following work:

- Kitty, Firefox, Thunar and Rofi shortcuts;
- Zsh starts in Kitty and `printf '%s\n' "$SHELL"` reports `/usr/bin/zsh`;
- completion ignores case, for example `cd dow` + Tab completes `Downloads`;
- Backspace at an empty Zsh prompt produces no audible bell;
- workspace switching and move-and-follow bindings;
- Wi-Fi, audio and brightness controls;
- Waybar, notifications and locking;
- logout and return to Plasma.

Inspect the actual display identifier and available modes:

```bash
swaymsg -t get_outputs
```

The config assumes the internal connector is `eDP-1`. If it is named
differently, change the matching `output eDP-1` block in
`~/.config/sway/config`.

### 5. Opt into the full notch-bearing mode

Current Fedora Asahi kernels use the `appledrm` parameter. The older
`apple_dcp.show_notch=1` spelling found in older guides is obsolete.

After Sway itself is proven stable:

```bash
sudo grubby --update-kernel=ALL --args="appledrm.show_notch=1"
systemctl reboot
```

After rebooting, confirm both the argument and the 3024x1964 mode:

```bash
cat /proc/cmdline
swaymsg -t get_outputs
```

The supplied Sway config asks `eDP-1` for 3024x1964 at 60 Hz and 2x scale.
Sixty hertz is intentional for the battery-first baseline; fixed 120 Hz can be
tested later. Asahi does not currently provide macOS-style variable-refresh
ProMotion.

To undo the notch option:

```bash
sudo grubby --update-kernel=ALL --remove-args="appledrm.show_notch=1"
systemctl reboot
```

If Plasma selects the full panel mode after this change, it can independently
be set back to a notchless mode while Sway continues selecting 3024x1964.

## Requested keybindings

| Binding | Action |
| --- | --- |
| Command + 1...9 | Switch to workspace 1...9 |
| Command + 0 | Switch to workspace 10 |
| Command + Shift + 1...0 | Move the focused window and follow it |
| Command + Q | Close the focused window |
| Command + W | Open Firefox |
| Command + Return | Open Kitty |
| Command + N | Open Thunar |
| Command + R | Open Rofi |

`Mod4` maps to the MacBook's Command key. The config also includes ordinary
focus, move, split, layout, fullscreen, floating, scratchpad, volume,
brightness, lock, screenshot, reload and logout bindings.

## Intentional baseline assumptions

- British keyboard layout (`gb`)
- Command/Super as the modifier
- Zsh without Oh My Zsh or another plugin framework
- case-insensitive, menu-based tab completion
- silent Zsh, Kitty and legacy kernel PC-speaker bells
- 2x integer scaling
- 60 Hz initially
- no inner or outer gaps
- thin two-pixel borders without title bars
- tap-to-click and natural scrolling
- reduced touchpad scroll factor of 0.7
- a permanently visible, translucent notch-height bar
- more opaque rounded backgrounds for individual Waybar components

These are all local config changes and are easy to revise.

## Pywal phase (not applied yet)

The original Pywal project is archived. The later theming phase should use the
maintained `pywal16` fork, installed in an isolated Python environment (for
example with `pipx`). Kitty is already prepared to load
`~/.cache/wal/colors-kitty.conf` when it exists.

The second-stage theme script should:

1. choose or receive a wallpaper;
2. run `wal`/pywal16 to generate colours;
3. set the Sway wallpaper;
4. reload Kitty colours;
5. regenerate or reload Rofi, Waybar and Mako colours;
6. update Firefox through the appropriate Pywal-Firefox integration.

The Waybar backdrop and component pills should retain different alpha values
when colours are regenerated: approximately 0.46 for the bar and 0.84 for the
components. Generated colours can then alter their tint as well as the text,
focused-workspace and status accents without losing the layered effect.

## Recovery

If the Sway config causes a problem, select Plasma at the login screen and move
the user config aside:

```bash
mv ~/.config/sway/config ~/.config/sway/config.disabled
```

Sway will then fall back to its packaged configuration on the next login.

## References

- [Fedora Asahi Remix](https://asahilinux.org/fedora/)
- [Sway](https://swaywm.org/)
- [Fedora Sway Spin](https://fedoraproject.org/spins/sway/)
- [Rofi 2.0 release](https://github.com/davatorium/rofi/releases/tag/2.0.0)
- [Waybar configuration manual](https://man.archlinux.org/man/waybar.5.en)
- [Fedora Asahi kernel 6.18 notch-parameter rename](https://discussion.fedoraproject.org/t/new-asahi-kernel-release-6-18-10/181294)
