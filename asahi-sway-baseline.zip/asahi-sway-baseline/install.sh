#!/bin/sh

set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
config_root=${XDG_CONFIG_HOME:-"$HOME/.config"}
cache_root=${XDG_CACHE_HOME:-"$HOME/.cache"}
data_root=${XDG_DATA_HOME:-"$HOME/.local/share"}
state_root=${XDG_STATE_HOME:-"$HOME/.local/state"}
timestamp=$(date +%Y%m%d-%H%M%S)
backup_root="$config_root/asahi-sway-backup-$timestamp"
components="sway waybar mako kitty rofi zsh environment.d"
made_backup=0

install -d \
    "$config_root" \
    "$cache_root" \
    "$data_root" \
    "$state_root" \
    "$HOME/.local/bin" \
    "$HOME/apps" \
    "$HOME/dl" \
    "$HOME/docs" \
    "$HOME/music" \
    "$HOME/pics" \
    "$HOME/vids"

for component in $components; do
    target="$config_root/$component"
    if [ -e "$target" ]; then
        if [ "$made_backup" -eq 0 ]; then
            install -d "$backup_root"
            made_backup=1
        fi
        cp -a "$target" "$backup_root/"
    fi
done

zshenv_target="$HOME/.zshenv"
if [ -e "$zshenv_target" ] || [ -L "$zshenv_target" ]; then
    if [ "$made_backup" -eq 0 ]; then
        install -d "$backup_root"
        made_backup=1
    fi
    cp -a "$zshenv_target" "$backup_root/zshenv-home"
fi

user_dirs_target="$config_root/user-dirs.dirs"
if [ -e "$user_dirs_target" ] || [ -L "$user_dirs_target" ]; then
    if [ "$made_backup" -eq 0 ]; then
        install -d "$backup_root"
        made_backup=1
    fi
    cp -a "$user_dirs_target" "$backup_root/user-dirs.dirs"
fi

for component in $components; do
    source_dir="$script_dir/config/$component"
    target_dir="$config_root/$component"
    install -d "$target_dir"
    cp -a "$source_dir/." "$target_dir/"
done

install -m 0644 "$script_dir/home/.zshenv" "$zshenv_target"
install -m 0644 "$script_dir/config-root/user-dirs.dirs" "$user_dirs_target"

# Fedora/KDE may have created the conventional capitalised directories during
# the first Plasma login. Remove only empty ones; preserve and report anything
# containing user data rather than moving or deleting it silently.
legacy_user_dirs="Desktop Documents Downloads Music Pictures Public Templates Videos"
for legacy_dir in $legacy_user_dirs; do
    legacy_path="$HOME/$legacy_dir"
    if [ -d "$legacy_path" ] && [ ! -L "$legacy_path" ]; then
        if rmdir "$legacy_path" 2>/dev/null; then
            printf 'Removed empty legacy directory: %s\n' "$legacy_path"
        else
            printf 'Preserved non-empty legacy directory for review: %s\n' \
                "$legacy_path" >&2
        fi
    fi
done

if command -v sudo >/dev/null 2>&1; then
    if sudo install -m 0644 \
        "$script_dir/system/disable-pc-speaker.conf" \
        /etc/modprobe.d/disable-pc-speaker.conf; then
        sudo modprobe -r pcspkr snd_pcsp >/dev/null 2>&1 || true
        printf 'Disabled legacy kernel PC-speaker modules.\n'
    else
        printf 'Warning: could not install the PC-speaker blacklist.\n' >&2
    fi
fi

if command -v zsh >/dev/null 2>&1 && command -v chsh >/dev/null 2>&1; then
    zsh_path=$(command -v zsh)
    current_shell=$(getent passwd "$(id -un)" | cut -d: -f7)
    if [ "$current_shell" != "$zsh_path" ]; then
        printf 'Changing the login shell to %s.\n' "$zsh_path"
        if ! chsh -s "$zsh_path"; then
            printf 'Login shell unchanged; run: chsh -s %s\n' "$zsh_path" >&2
        fi
    fi
else
    printf 'Warning: zsh or chsh is unavailable; login shell was not changed.\n' >&2
fi

if [ "$made_backup" -eq 1 ]; then
    printf 'Existing configuration backed up to: %s\n' "$backup_root"
fi

printf 'Installed Sway baseline beneath: %s\n' "$config_root"
printf 'Visible home folders: apps, dl, docs, music, pics, vids\n'
printf 'Log out completely for the new login shell, then select Sway.\n'
