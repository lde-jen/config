#!/bin/sh

set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
config_root=${XDG_CONFIG_HOME:-"$HOME/.config"}
timestamp=$(date +%Y%m%d-%H%M%S)
backup_root="$config_root/asahi-sway-backup-$timestamp"
components="sway waybar mako kitty rofi zsh"
made_backup=0

install -d "$config_root"

for component in $components; do
    target="$config_root/$component"
    if [ -e "$target" ]; then
        if [ "$made_backup" -eq 0 ]; then
            install -d "$backup_root"
            made_backup=1
        fi
        cp -a "$target" "$backup_root/"
    fi
done

zshenv_target="$HOME/.zshenv"
if [ -e "$zshenv_target" ] || [ -L "$zshenv_target" ]; then
    if [ "$made_backup" -eq 0 ]; then
        install -d "$backup_root"
        made_backup=1
    fi
    cp -a "$zshenv_target" "$backup_root/zshenv-home"
fi

for component in $components; do
    source_dir="$script_dir/config/$component"
    target_dir="$config_root/$component"
    install -d "$target_dir"
    cp -a "$source_dir/." "$target_dir/"
done

install -m 0644 "$script_dir/home/.zshenv" "$zshenv_target"

if command -v sudo >/dev/null 2>&1; then
    if sudo install -m 0644 \
        "$script_dir/system/disable-pc-speaker.conf" \
        /etc/modprobe.d/disable-pc-speaker.conf; then
        sudo modprobe -r pcspkr snd_pcsp >/dev/null 2>&1 || true
        printf 'Disabled legacy kernel PC-speaker modules.\n'
    else
        printf 'Warning: could not install the PC-speaker blacklist.\n' >&2
    fi
fi

if command -v zsh >/dev/null 2>&1 && command -v chsh >/dev/null 2>&1; then
    zsh_path=$(command -v zsh)
    current_shell=$(getent passwd "$(id -un)" | cut -d: -f7)
    if [ "$current_shell" != "$zsh_path" ]; then
        printf 'Changing the login shell to %s.\n' "$zsh_path"
        if ! chsh -s "$zsh_path"; then
            printf 'Login shell unchanged; run: chsh -s %s\n' "$zsh_path" >&2
        fi
    fi
else
    printf 'Warning: zsh or chsh is unavailable; login shell was not changed.\n' >&2
fi

if [ "$made_backup" -eq 1 ]; then
    printf 'Existing configuration backed up to: %s\n' "$backup_root"
fi

printf 'Installed Sway baseline beneath: %s\n' "$config_root"
printf 'Log out completely for the new login shell, then select Sway.\n'
