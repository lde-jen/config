# Small, framework-free interactive Zsh baseline.

# Never ring Zsh's audible bell for completion or editing errors.
unsetopt BEEP

# Familiar Emacs-style line editing keys.
bindkey -e

# Cache completion metadata outside $HOME.
zsh_cache_dir="${XDG_CACHE_HOME:-$HOME/.cache}/zsh"
mkdir -p "$zsh_cache_dir"

autoload -Uz compinit
compinit -d "$zsh_cache_dir/zcompdump-$ZSH_VERSION"

# Complete filenames and commands without regard to letter case.
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'
zstyle ':completion:*' menu select

# Keep persistent history in the XDG state directory.
HISTFILE="${XDG_STATE_HOME:-$HOME/.local/state}/zsh/history"
mkdir -p "${HISTFILE:h}"
HISTSIZE=10000
SAVEHIST=10000
setopt APPEND_HISTORY
setopt INC_APPEND_HISTORY
setopt HIST_IGNORE_ALL_DUPS
setopt HIST_REDUCE_BLANKS

# Compact prompt with the current user, host and directory.
PROMPT='%F{green}%n@%m%f:%F{blue}%~%f%# '
